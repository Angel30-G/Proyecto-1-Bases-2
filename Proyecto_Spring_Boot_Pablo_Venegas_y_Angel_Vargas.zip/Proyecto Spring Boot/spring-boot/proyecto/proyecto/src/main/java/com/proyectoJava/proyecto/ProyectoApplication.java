package com.proyectoJava.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoApplication {

	//Llama y ejecuta el proyecto de Spring boot
	public static void main(String[] args) {
		SpringApplication.run(ProyectoApplication.class, args);
	}

}
